package org.telegram.messenger.glassx;

import android.graphics.Color;
import android.util.SparseIntArray;

import androidx.core.graphics.ColorUtils;

import org.telegram.ui.ActionBar.Theme;

/**
 * Overlays the Liquid Glass palette on top of the table that Theme.refreshThemeColors() builds.
 * Only colors are touched, so every existing theme mechanism keeps working.
 */
public class GlassThemeEngine {

    public static final class Palette {
        public final boolean dark;
        public final int bg, surface, text, subtext, accent, glowA, glowB, glowC, divider;
        Palette(boolean dark, int bg, int surface, int text, int subtext, int accent, int glowA, int glowB, int glowC, int divider) {
            this.dark = dark; this.bg = bg; this.surface = surface; this.text = text; this.subtext = subtext;
            this.accent = accent; this.glowA = glowA; this.glowB = glowB; this.glowC = glowC; this.divider = divider;
        }
    }

    public static final String[] THEME_NAMES = {"Светлое стекло", "Тёмное стекло", "Океан", "Закат", "Мята"};

    public static Palette palette() {
        GlassConfig.load();
        Palette p;
        switch (GlassConfig.theme) {
            case GlassConfig.THEME_DARK:
                p = new Palette(true, 0xFF000000, 0xFF1C1C1E, 0xFFFFFFFF, 0xFF8E8E93, 0xFF0A84FF, 0xFF0A84FF, 0xFFBF5AF2, 0xFF64D2FF, 0xFF38383A);
                break;
            case GlassConfig.THEME_OCEAN:
                p = new Palette(true, 0xFF06141F, 0xFF0E2433, 0xFFEAF6FF, 0xFF7FA6BF, 0xFF64D2FF, 0xFF0A84FF, 0xFF30D5C8, 0xFF5E5CE6, 0xFF1D3A4D);
                break;
            case GlassConfig.THEME_SUNSET:
                p = new Palette(false, 0xFFFFF4EC, 0xFFFFFFFF, 0xFF2B1B17, 0xFF9A7B70, 0xFFFF6B3D, 0xFFFF9F0A, 0xFFFF375F, 0xFFBF5AF2, 0xFFF1DCD0);
                break;
            case GlassConfig.THEME_MINT:
                p = new Palette(false, 0xFFEFFAF5, 0xFFFFFFFF, 0xFF10261D, 0xFF6F8F80, 0xFF30D158, 0xFF30D158, 0xFF64D2FF, 0xFFFFD60A, 0xFFD3EBE0);
                break;
            default:
                p = new Palette(false, 0xFFF2F2F7, 0xFFFFFFFF, 0xFF000000, 0xFF8E8E93, 0xFF0A84FF, 0xFF0A84FF, 0xFFBF5AF2, 0xFF64D2FF, 0xFFD1D1D6);
                break;
        }
        if (GlassConfig.accentIndex >= 0 && GlassConfig.accentIndex < GlassConfig.ACCENTS.length) {
            return new Palette(p.dark, p.bg, p.surface, p.text, p.subtext, GlassConfig.ACCENTS[GlassConfig.accentIndex], p.glowA, p.glowB, p.glowC, p.divider);
        }
        return p;
    }

    /** Called from Theme.refreshThemeColors() right before the table is published. */
    public static void apply(SparseIntArray c) {
        final Palette p = palette();
        final int accent = p.accent;
        final int onAccent = ColorUtils.calculateLuminance(accent) > 0.6 ? Color.BLACK : Color.WHITE;

        c.put(Theme.key_windowBackgroundWhite, p.surface);
        c.put(Theme.key_windowBackgroundGray, p.bg);
        c.put(Theme.key_windowBackgroundWhiteBlackText, p.text);
        c.put(Theme.key_windowBackgroundWhiteGrayText2, p.subtext);
        c.put(Theme.key_windowBackgroundWhiteBlueText, accent);
        c.put(Theme.key_windowBackgroundWhiteBlueHeader, accent);
        c.put(Theme.key_divider, p.divider);

        c.put(Theme.key_actionBarDefault, p.surface);
        c.put(Theme.key_actionBarDefaultTitle, p.text);
        c.put(Theme.key_actionBarDefaultIcon, p.text);

        c.put(Theme.key_dialogBackground, p.surface);
        c.put(Theme.key_dialogTextBlack, p.text);

        c.put(Theme.key_chats_actionBackground, accent);
        c.put(Theme.key_chats_unreadCounter, accent);
        c.put(Theme.key_featuredStickers_addButton, accent);
        c.put(Theme.key_chat_messagePanelSend, accent);
        c.put(Theme.key_chat_messagePanelBackground, p.surface);
        c.put(Theme.key_chat_wallpaper, p.bg);

        // message bubbles: always opaque enough to keep text crisp
        final int outBubble;
        final int inBubble;
        switch (GlassConfig.bubbleStyle) {
            case GlassConfig.BUBBLE_GLASS:
                outBubble = ColorUtils.setAlphaComponent(accent, 0xE6);
                inBubble = ColorUtils.setAlphaComponent(p.surface, 0xEB);
                break;
            case GlassConfig.BUBBLE_FLAT:
                outBubble = ColorUtils.blendARGB(accent, p.bg, 0.78f);
                inBubble = ColorUtils.blendARGB(p.surface, p.bg, 0.4f);
                break;
            default:
                outBubble = accent;
                inBubble = p.dark ? 0xFF26262A : 0xFFE9E9EB;
                break;
        }
        final boolean flat = GlassConfig.bubbleStyle == GlassConfig.BUBBLE_FLAT;
        c.put(Theme.key_chat_outBubble, outBubble);
        c.put(Theme.key_chat_outBubbleSelected, ColorUtils.blendARGB(outBubble, Color.BLACK, 0.12f));
        c.put(Theme.key_chat_outBubbleGradient1, outBubble);
        c.put(Theme.key_chat_inBubble, inBubble);
        c.put(Theme.key_chat_inBubbleSelected, ColorUtils.blendARGB(inBubble, p.dark ? Color.WHITE : Color.BLACK, 0.08f));
        c.put(Theme.key_chat_messageTextOut, flat ? p.text : onAccent);
        c.put(Theme.key_chat_messageTextIn, p.text);
    }
}
