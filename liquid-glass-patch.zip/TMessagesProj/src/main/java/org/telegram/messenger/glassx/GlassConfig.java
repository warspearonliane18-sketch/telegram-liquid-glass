package org.telegram.messenger.glassx;

import android.content.Context;
import android.content.SharedPreferences;

import org.telegram.messenger.ApplicationLoader;
import org.telegram.messenger.NotificationCenter;
import org.telegram.messenger.SharedConfig;

/**
 * Central store for the iOS Liquid Glass look, the AI assistant and ghost mode.
 * Every setter persists immediately and calls {@link #notifyChanged()} so the UI re-skins without a restart.
 */
public class GlassConfig {

    public static final int THEME_LIGHT = 0;
    public static final int THEME_DARK = 1;
    public static final int THEME_OCEAN = 2;
    public static final int THEME_SUNSET = 3;
    public static final int THEME_MINT = 4;
    public static final int THEME_COUNT = 5;

    public static final int BUBBLE_IOS = 0;
    public static final int BUBBLE_GLASS = 1;
    public static final int BUBBLE_FLAT = 2;

    /** Accent palette, index -1 means "use the accent of the selected theme". */
    public static final int[] ACCENTS = {
            0xFF0A84FF, // iOS blue
            0xFF30D158, // green
            0xFFFF9F0A, // orange
            0xFFFF375F, // pink
            0xFFBF5AF2, // purple
            0xFF64D2FF, // cyan
            0xFFFF453A, // red
            0xFFFFD60A  // yellow
    };

    public static final String DEFAULT_GEMINI_KEY = "AQ.Ab8RN6IB9sXmdYejrf35Bsp4wQmcVOqkv14UMjQrp_QQytafuQ";
    public static final String DEFAULT_GEMINI_MODEL = "gemini-2.0-flash";
    public static final String DEFAULT_SYSTEM_PROMPT = "Ты — дружелюбный ИИ-ассистент, встроенный в мессенджер. Отвечай кратко, по делу и на языке пользователя.";

    private static SharedPreferences prefs;

    public static int theme = THEME_LIGHT;
    public static int accentIndex = -1;
    public static int bubbleStyle = BUBBLE_IOS;
    public static int glassBlur = 70;      // 0..100
    public static int glassAlpha = 60;     // 0..100 (opacity of glass layers)
    public static int cornerRadius = 20;   // 8..30 dp
    public static boolean liquidGlow = true;

    public static String geminiKey = DEFAULT_GEMINI_KEY;
    public static String geminiModel = DEFAULT_GEMINI_MODEL;
    public static String systemPrompt = DEFAULT_SYSTEM_PROMPT;

    public static boolean ghostNoRead = false;
    public static boolean ghostNoTyping = false;

    private static boolean loaded;

    private static SharedPreferences prefs() {
        if (prefs == null) {
            prefs = ApplicationLoader.applicationContext.getSharedPreferences("glassx", Context.MODE_PRIVATE);
        }
        return prefs;
    }

    public static synchronized void load() {
        if (loaded) {
            return;
        }
        SharedPreferences p = prefs();
        theme = p.getInt("theme", THEME_LIGHT);
        accentIndex = p.getInt("accent", -1);
        bubbleStyle = p.getInt("bubbleStyle", BUBBLE_IOS);
        glassBlur = p.getInt("glassBlur", 70);
        glassAlpha = p.getInt("glassAlpha", 60);
        cornerRadius = p.getInt("cornerRadius", 20);
        liquidGlow = p.getBoolean("liquidGlow", true);
        geminiKey = p.getString("geminiKey", DEFAULT_GEMINI_KEY);
        geminiModel = p.getString("geminiModel", DEFAULT_GEMINI_MODEL);
        systemPrompt = p.getString("systemPrompt", DEFAULT_SYSTEM_PROMPT);
        ghostNoRead = p.getBoolean("ghostNoRead", false);
        ghostNoTyping = p.getBoolean("ghostNoTyping", false);
        SharedConfig.bubbleRadius = Math.max(8, Math.min(30, cornerRadius - 3));
        loaded = true;
    }

    public static void save() {
        prefs().edit()
                .putInt("theme", theme)
                .putInt("accent", accentIndex)
                .putInt("bubbleStyle", bubbleStyle)
                .putInt("glassBlur", glassBlur)
                .putInt("glassAlpha", glassAlpha)
                .putInt("cornerRadius", cornerRadius)
                .putBoolean("liquidGlow", liquidGlow)
                .putString("geminiKey", geminiKey)
                .putString("geminiModel", geminiModel)
                .putString("systemPrompt", systemPrompt)
                .putBoolean("ghostNoRead", ghostNoRead)
                .putBoolean("ghostNoTyping", ghostNoTyping)
                .apply();
    }

    /** Persist and push the change into the live theme (no restart needed). */
    public static void notifyChanged() {
        save();
        // keep the chat bubble corner radius in sync with the glass corner radius
        SharedConfig.bubbleRadius = Math.max(8, Math.min(30, cornerRadius - 3));
        org.telegram.ui.ActionBar.Theme.refreshThemeColors();
    }

    public static void resetGeminiKey() {
        geminiKey = DEFAULT_GEMINI_KEY;
        save();
    }

    public static boolean isDark() {
        return theme == THEME_DARK || theme == THEME_OCEAN;
    }

    public static boolean isGhostBlockingRead() {
        return ghostNoRead;
    }

    public static boolean isGhostBlockingTyping() {
        return ghostNoTyping;
    }
}
