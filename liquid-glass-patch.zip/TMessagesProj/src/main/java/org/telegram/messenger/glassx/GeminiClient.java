package org.telegram.messenger.glassx;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.Utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Minimal Gemini REST client (generateContent). Callbacks are always delivered on the UI thread. */
public class GeminiClient {

    public static class Turn {
        public final boolean fromUser;
        public final String text;
        public Turn(boolean fromUser, String text) {
            this.fromUser = fromUser;
            this.text = text;
        }
    }

    public interface Callback {
        void onResult(String text);
        void onError(String message);
    }

    private static final String ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent";

    /** Sends the whole history (the last turn must be the user's) and reports the model reply. */
    public static void send(List<Turn> history, Callback callback) {
        GlassConfig.load();
        final String key = GlassConfig.geminiKey == null ? "" : GlassConfig.geminiKey.trim();
        final String model = TextUtils.isEmpty(GlassConfig.geminiModel) ? GlassConfig.DEFAULT_GEMINI_MODEL : GlassConfig.geminiModel.trim();
        final String system = GlassConfig.systemPrompt;
        if (key.isEmpty()) {
            AndroidUtilities.runOnUIThread(() -> callback.onError("API-ключ не задан. Укажите его в настройках ИИ."));
            return;
        }
        final JSONObject body;
        try {
            body = new JSONObject();
            JSONArray contents = new JSONArray();
            for (Turn turn : history) {
                JSONObject c = new JSONObject();
                c.put("role", turn.fromUser ? "user" : "model");
                c.put("parts", new JSONArray().put(new JSONObject().put("text", turn.text)));
                contents.put(c);
            }
            body.put("contents", contents);
            if (!TextUtils.isEmpty(system)) {
                body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
            }
        } catch (JSONException e) {
            AndroidUtilities.runOnUIThread(() -> callback.onError("Не удалось собрать запрос: " + e.getMessage()));
            return;
        }

        Utilities.globalQueue.postRunnable(() -> {
            HttpURLConnection conn = null;
            String result = null;
            String error = null;
            try {
                URL url = new URL(String.format(ENDPOINT, model));
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("x-goog-api-key", key);
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payload);
                }
                final int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                String response = readAll(stream);
                if (code >= 200 && code < 300) {
                    result = parseText(response);
                    if (TextUtils.isEmpty(result)) {
                        error = parseBlockReason(response);
                    }
                } else {
                    error = describeHttpError(code, response);
                }
            } catch (UnknownHostException e) {
                error = "Нет подключения к интернету.";
            } catch (SocketTimeoutException e) {
                error = "Превышено время ожидания ответа от Gemini.";
            } catch (IOException e) {
                error = "Ошибка сети: " + e.getMessage();
            } catch (Exception e) {
                error = "Ошибка: " + e.getMessage();
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
            final String fr = result;
            final String fe = error;
            AndroidUtilities.runOnUIThread(() -> {
                if (fr != null && !fr.isEmpty()) {
                    callback.onResult(fr);
                } else {
                    callback.onError(fe != null ? fe : "Пустой ответ от модели.");
                }
            });
        });
    }

    private static String readAll(InputStream stream) throws IOException {
        if (stream == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            char[] buf = new char[4096];
            int n;
            while ((n = r.read(buf)) > 0) {
                sb.append(buf, 0, n);
            }
        }
        return sb.toString();
    }

    private static String parseText(String json) {
        try {
            JSONArray candidates = new JSONObject(json).optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                return null;
            }
            JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
            if (content == null) {
                return null;
            }
            JSONArray parts = content.optJSONArray("parts");
            if (parts == null) {
                return null;
            }
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) {
                sb.append(parts.getJSONObject(i).optString("text", ""));
            }
            return sb.toString().trim();
        } catch (JSONException e) {
            return null;
        }
    }

    private static String parseBlockReason(String json) {
        try {
            JSONObject feedback = new JSONObject(json).optJSONObject("promptFeedback");
            if (feedback != null && feedback.has("blockReason")) {
                return "Запрос заблокирован фильтрами модели (" + feedback.getString("blockReason") + ").";
            }
        } catch (JSONException ignore) {
        }
        return "Модель не вернула текст.";
    }

    private static String describeHttpError(int code, String body) {
        String message = null;
        try {
            JSONObject err = new JSONObject(body).optJSONObject("error");
            if (err != null) {
                message = err.optString("message", null);
            }
        } catch (JSONException ignore) {
        }
        String prefix;
        switch (code) {
            case 400: prefix = "Неверный запрос или ключ (400)"; break;
            case 401: prefix = "Ключ не принят (401)"; break;
            case 403: prefix = "Доступ запрещён, проверьте API-ключ (403)"; break;
            case 404: prefix = "Модель не найдена (404)"; break;
            case 429: prefix = "Превышен лимит запросов (429)"; break;
            default: prefix = code >= 500 ? "Сервис Gemini недоступен (" + code + ")" : "Ошибка API (" + code + ")"; break;
        }
        return TextUtils.isEmpty(message) ? prefix : prefix + ": " + message;
    }
}
