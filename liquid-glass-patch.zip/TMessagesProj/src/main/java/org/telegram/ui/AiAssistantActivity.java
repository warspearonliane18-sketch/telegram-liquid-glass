package org.telegram.ui;

import static org.telegram.messenger.AndroidUtilities.dp;

import android.animation.ObjectAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.graphics.ColorUtils;

import org.json.JSONArray;
import org.json.JSONObject;
import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.ApplicationLoader;
import org.telegram.messenger.NotificationCenter;
import org.telegram.messenger.R;
import org.telegram.messenger.glassx.GeminiClient;
import org.telegram.messenger.glassx.GlassConfig;
import org.telegram.messenger.glassx.GlassThemeEngine;
import org.telegram.ui.ActionBar.BaseFragment;
import org.telegram.ui.Components.LayoutHelper;
import org.telegram.ui.Components.SizeNotifierFrameLayout;
import org.telegram.ui.Components.glass.LiquidGlassKit;

import java.util.ArrayList;

/** "ИИ" tab: iOS Liquid Glass chat with Gemini. History is kept in storage and survives restarts. */
public class AiAssistantActivity extends BaseFragment implements MainTabsActivity.TabFragmentDelegate, NotificationCenter.NotificationCenterDelegate {

    private static final String HISTORY_PREF = "glassx_ai_history";
    private static final int MAX_STORED = 60;

    private final ArrayList<GeminiClient.Turn> history = new ArrayList<>();
    private SizeNotifierFrameLayout root;
    private LiquidGlassKit.AuroraView aurora;
    private ScrollView scroll;
    private LinearLayout messages;
    private EditText input;
    private ImageView sendButton;
    private LinearLayout inputBar;
    private LinearLayout header;
    private TextView titleView;
    private TextView subtitleView;
    private LinearLayout typingRow;
    private boolean waiting;
    private int keyboardHeight;

    public AiAssistantActivity(android.os.Bundle args) {
        super(args);
    }

    @Override
    public boolean onFragmentCreate() {
        GlassConfig.load();
        loadHistory();
        getNotificationCenter().addObserver(this, NotificationCenter.didSetNewTheme);
        return super.onFragmentCreate();
    }

    @Override
    public void onFragmentDestroy() {
        getNotificationCenter().removeObserver(this, NotificationCenter.didSetNewTheme);
        super.onFragmentDestroy();
    }

    @Override
    public void didReceivedNotification(int id, int account, Object... args) {
        if (id == NotificationCenter.didSetNewTheme && root != null) {
            rebuildMessages();
            applyGlassStyles();
        }
    }

    @Override
    public android.view.View createView(Context context) {
        setHasOwnBackground(true);
        actionBar.setAddToContainer(false);

        root = new SizeNotifierFrameLayout(context) {
            @Override
            protected void onMeasure(int w, int h) {
                super.onMeasure(w, h);
            }
        };
        root.setDelegate((kb, wide) -> {
            keyboardHeight = kb;
            updateBottomInset();
        });
        fragmentView = root;

        aurora = new LiquidGlassKit.AuroraView(context);
        root.addView(aurora, LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, LayoutHelper.MATCH_PARENT));

        scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        messages = new LinearLayout(context);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(dp(12), 0, dp(12), dp(8));
        scroll.addView(messages, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, LayoutHelper.MATCH_PARENT));

        buildHeader(context);
        buildInputBar(context);
        applyGlassStyles();
        rebuildMessages();
        updateBottomInset();
        return root;
    }

    private void buildHeader(Context context) {
        header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(8), dp(8), dp(8));

        LinearLayout titles = new LinearLayout(context);
        titles.setOrientation(LinearLayout.VERTICAL);
        titleView = new TextView(context);
        titleView.setText("ИИ-ассистент");
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        subtitleView = new TextView(context);
        subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        titles.addView(titleView);
        titles.addView(subtitleView);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        header.addView(headerButton(context, R.drawable.msg_clear, "Очистить диалог", v -> clearHistory()));
        header.addView(headerButton(context, R.drawable.msg_settings, "Настройки ИИ", v -> presentFragment(new GlassSettingsActivity())));

        FrameLayout.LayoutParams lp = LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, Gravity.TOP, 10, 0, 10, 0);
        root.addView(header, lp);
    }

    private ImageView headerButton(Context context, int icon, String description, View.OnClickListener listener) {
        ImageView b = new ImageView(context);
        b.setImageResource(icon);
        b.setScaleType(ImageView.ScaleType.CENTER);
        b.setContentDescription(description);
        b.setOnClickListener(listener);
        LiquidGlassKit.applyPressEffect(b);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        return b;
    }

    private void buildInputBar(Context context) {
        inputBar = new LinearLayout(context);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setGravity(Gravity.BOTTOM);
        inputBar.setPadding(dp(14), dp(4), dp(6), dp(4));

        input = new EditText(context);
        input.setHint("Спросите что угодно…");
        input.setBackground(null);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        input.setMaxLines(5);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        input.setPadding(0, dp(10), 0, dp(10));
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { updateSendState(); }
        });
        inputBar.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        sendButton = new ImageView(context);
        sendButton.setImageResource(R.drawable.ic_send);
        sendButton.setScaleType(ImageView.ScaleType.CENTER);
        sendButton.setOnClickListener(v -> sendCurrent());
        LiquidGlassKit.applyPressEffect(sendButton);
        inputBar.addView(sendButton, new LinearLayout.LayoutParams(dp(38), dp(38)));

        root.addView(inputBar, LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, LayoutHelper.WRAP_CONTENT, Gravity.BOTTOM, 10, 0, 10, 0));
    }

    private void applyGlassStyles() {
        if (root == null) return;
        GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        aurora.refresh();
        header.setBackground(LiquidGlassKit.glass(LiquidGlassKit.cornerDp() + 6, true));
        header.setElevation(dp(4));
        titleView.setTextColor(p.text);
        subtitleView.setTextColor(p.subtext);
        subtitleView.setText("Gemini · " + GlassConfig.geminiModel);
        inputBar.setBackground(LiquidGlassKit.glass(LiquidGlassKit.cornerDp() + 6, true));
        inputBar.setElevation(dp(6));
        input.setTextColor(p.text);
        input.setHintTextColor(p.subtext);
        for (int i = 0; i < header.getChildCount(); i++) {
            View c = header.getChildAt(i);
            if (c instanceof ImageView) ((ImageView) c).setColorFilter(p.accent);
        }
        updateSendState();
    }

    private void updateSendState() {
        if (sendButton == null) return;
        GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        boolean enabled = !waiting && input.getText().toString().trim().length() > 0;
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(enabled ? p.accent : ColorUtils.setAlphaComponent(p.subtext, 90));
        sendButton.setBackground(bg);
        sendButton.setColorFilter(Color.WHITE);
        sendButton.setEnabled(enabled);
    }

    private void updateBottomInset() {
        if (root == null) return;
        final int tabs = keyboardHeight > dp(80) ? 0 : dp(DialogsActivity.MAIN_TABS_HEIGHT_WITH_MARGINS);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) inputBar.getLayoutParams();
        lp.bottomMargin = tabs + keyboardHeight + dp(8);
        inputBar.setLayoutParams(lp);
        scroll.setPadding(0, dp(AndroidUtilities.statusBarHeight / Math.max(1f, AndroidUtilities.density)) + dp(64), 0, tabs + keyboardHeight + dp(76));
        FrameLayout.LayoutParams hp = (FrameLayout.LayoutParams) header.getLayoutParams();
        hp.topMargin = AndroidUtilities.statusBarHeight + dp(4);
        header.setLayoutParams(hp);
        scrollToBottom();
    }

    private void scrollToBottom() {
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    /* ---------- conversation ---------- */

    private void sendCurrent() {
        final String text = input.getText().toString().trim();
        if (text.isEmpty() || waiting) return;
        input.setText("");
        history.add(new GeminiClient.Turn(true, text));
        saveHistory();
        addBubble(true, text, false);
        requestReply();
    }

    private void requestReply() {
        waiting = true;
        updateSendState();
        showTyping(true);
        GeminiClient.send(new ArrayList<>(history), new GeminiClient.Callback() {
            @Override
            public void onResult(String text) {
                waiting = false;
                showTyping(false);
                history.add(new GeminiClient.Turn(false, text));
                saveHistory();
                addBubble(false, text, false);
                updateSendState();
            }

            @Override
            public void onError(String message) {
                waiting = false;
                showTyping(false);
                addErrorBubble(message);
                updateSendState();
            }
        });
    }

    private void clearHistory() {
        history.clear();
        saveHistory();
        rebuildMessages();
    }

    private void rebuildMessages() {
        if (messages == null) return;
        messages.removeAllViews();
        typingRow = null;
        if (history.isEmpty()) {
            addWelcome();
        }
        for (GeminiClient.Turn t : history) {
            addBubble(t.fromUser, t.text, true);
        }
        if (waiting) showTyping(true);
        scrollToBottom();
    }

    private void addWelcome() {
        GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        TextView hello = new TextView(getContext());
        hello.setText("Привет! Я ИИ-ассистент на базе Gemini.\nСпросите о чём угодно — напишу текст, объясню, переведу или помогу с кодом.");
        hello.setTextColor(p.text);
        hello.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        hello.setGravity(Gravity.CENTER);
        hello.setPadding(dp(20), dp(18), dp(20), dp(18));
        hello.setBackground(LiquidGlassKit.glass(LiquidGlassKit.cornerDp(), false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(24);
        messages.addView(hello, lp);
    }

    private void addBubble(boolean mine, String text, boolean silent) {
        if (history.size() == 1 && messages.getChildCount() == 1 && !silent) {
            // replace the welcome card with the first message
            messages.removeAllViews();
        }
        GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        final int accent = p.accent;
        final boolean light = ColorUtils.calculateLuminance(accent) > 0.6;
        TextView tv = new TextView(getContext());
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tv.setLineSpacing(0, 1.1f);
        tv.setTextIsSelectable(false);
        tv.setPadding(dp(14), dp(9), dp(14), dp(9));
        tv.setMaxWidth((int) (AndroidUtilities.displaySize.x * 0.82f));
        if (mine) {
            tv.setText(text);
            tv.setTextColor(light ? Color.BLACK : Color.WHITE);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{ColorUtils.blendARGB(accent, Color.WHITE, 0.18f), accent});
            g.setCornerRadius(dp(LiquidGlassKit.cornerDp()));
            tv.setBackground(g);
        } else {
            tv.setText(formatMarkdown(text, p));
            tv.setTextColor(p.text);
            tv.setBackground(LiquidGlassKit.glass(LiquidGlassKit.cornerDp(), true));
            tv.setOnLongClickListener(v -> {
                ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("AI", text));
                Toast.makeText(getContext(), "Скопировано", Toast.LENGTH_SHORT).show();
                return true;
            });
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = mine ? Gravity.END : Gravity.START;
        lp.topMargin = dp(6);
        if (typingRow != null && typingRow.getParent() == messages) {
            messages.addView(tv, messages.indexOfChild(typingRow), lp);
        } else {
            messages.addView(tv, lp);
        }
        tv.setAlpha(0f);
        tv.setTranslationY(dp(10));
        tv.animate().alpha(1f).translationY(0).setDuration(220).start();
        scrollToBottom();
    }

    private void addErrorBubble(String message) {
        TextView tv = new TextView(getContext());
        tv.setText("⚠️ " + message);
        tv.setTextColor(0xFFFF453A);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setPadding(dp(14), dp(9), dp(14), dp(9));
        tv.setBackground(LiquidGlassKit.glass(LiquidGlassKit.cornerDp(), true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.START;
        lp.topMargin = dp(6);
        messages.addView(tv, lp);
        tv.setOnClickListener(v -> {
            if (!waiting && !history.isEmpty() && history.get(history.size() - 1).fromUser) {
                messages.removeView(tv);
                requestReply();
            }
        });
        scrollToBottom();
    }

    private void showTyping(boolean show) {
        if (messages == null) return;
        if (!show) {
            if (typingRow != null) {
                messages.removeView(typingRow);
                typingRow = null;
            }
            return;
        }
        if (typingRow != null) return;
        GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        typingRow = new LinearLayout(getContext());
        typingRow.setOrientation(LinearLayout.HORIZONTAL);
        typingRow.setPadding(dp(16), dp(14), dp(16), dp(14));
        typingRow.setBackground(LiquidGlassKit.glass(LiquidGlassKit.cornerDp(), true));
        for (int i = 0; i < 3; i++) {
            View dot = new View(getContext());
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(p.subtext);
            dot.setBackground(d);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(8), dp(8));
            dl.leftMargin = i == 0 ? 0 : dp(5);
            typingRow.addView(dot, dl);
            ObjectAnimator a = ObjectAnimator.ofFloat(dot, View.TRANSLATION_Y, 0, -dp(5), 0);
            a.setDuration(700);
            a.setStartDelay(i * 150L);
            a.setRepeatCount(ObjectAnimator.INFINITE);
            a.start();
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.START;
        lp.topMargin = dp(6);
        messages.addView(typingRow, lp);
        scrollToBottom();
    }

    /* ---------- formatting: **bold**, *italic*, `code`, ```blocks```, "- " bullets, # headings ---------- */

    static CharSequence formatMarkdown(String src, GlassThemeEngine.Palette p) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        final int codeBg = ColorUtils.setAlphaComponent(p.dark ? Color.WHITE : Color.BLACK, 28);
        boolean inBlock = false;
        String[] lines = src.split("\n", -1);
        for (int li = 0; li < lines.length; li++) {
            String line = lines[li];
            if (line.trim().startsWith("```")) {
                inBlock = !inBlock;
                continue;
            }
            int start = out.length();
            if (inBlock) {
                out.append(line);
                out.setSpan(new TypefaceSpan("monospace"), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                out.setSpan(new BackgroundColorSpan(codeBg), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else {
                String l = line;
                boolean heading = false;
                if (l.startsWith("### ") || l.startsWith("## ") || l.startsWith("# ")) {
                    l = l.replaceFirst("^#+\\s+", "");
                    heading = true;
                } else if (l.startsWith("- ") || l.startsWith("* ")) {
                    l = "•  " + l.substring(2);
                }
                out.append(applyInline(l, codeBg));
                if (heading) {
                    out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    out.setSpan(new RelativeSizeSpan(1.15f), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
            if (li < lines.length - 1) out.append('\n');
        }
        return out;
    }

    private static CharSequence applyInline(String s, int codeBg) {
        SpannableStringBuilder b = new SpannableStringBuilder();
        int i = 0;
        while (i < s.length()) {
            if (s.startsWith("**", i)) {
                int e = s.indexOf("**", i + 2);
                if (e > 0) {
                    int st = b.length();
                    b.append(s, i + 2, e);
                    b.setSpan(new StyleSpan(Typeface.BOLD), st, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = e + 2;
                    continue;
                }
            } else if (s.charAt(i) == '`') {
                int e = s.indexOf('`', i + 1);
                if (e > 0) {
                    int st = b.length();
                    b.append(s, i + 1, e);
                    b.setSpan(new TypefaceSpan("monospace"), st, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    b.setSpan(new BackgroundColorSpan(codeBg), st, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = e + 1;
                    continue;
                }
            } else if (s.charAt(i) == '*' && i + 1 < s.length() && s.charAt(i + 1) != ' ') {
                int e = s.indexOf('*', i + 1);
                if (e > 0 && !s.startsWith("**", e)) {
                    int st = b.length();
                    b.append(s, i + 1, e);
                    b.setSpan(new StyleSpan(Typeface.ITALIC), st, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = e + 1;
                    continue;
                }
            }
            b.append(s.charAt(i));
            i++;
        }
        return b;
    }

    /* ---------- storage ---------- */

    private void loadHistory() {
        history.clear();
        try {
            String raw = ApplicationLoader.applicationContext.getSharedPreferences("glassx", Context.MODE_PRIVATE).getString(HISTORY_PREF, "[]");
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                history.add(new GeminiClient.Turn(o.getBoolean("u"), o.getString("t")));
            }
        } catch (Exception ignore) {
            history.clear();
        }
    }

    private void saveHistory() {
        try {
            while (history.size() > MAX_STORED) history.remove(0);
            JSONArray arr = new JSONArray();
            for (GeminiClient.Turn t : history) {
                arr.put(new JSONObject().put("u", t.fromUser).put("t", t.text));
            }
            ApplicationLoader.applicationContext.getSharedPreferences("glassx", Context.MODE_PRIVATE).edit().putString(HISTORY_PREF, arr.toString()).apply();
        } catch (Exception ignore) {
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        applyGlassStyles();
    }

    @Override
    public void onParentScrollToTop() {
        if (scroll != null) scroll.smoothScrollTo(0, 0);
    }

    @Override
    public boolean isLightStatusBar() {
        return !GlassThemeEngine.palette().dark;
    }
}
