package org.telegram.ui;

import static org.telegram.messenger.AndroidUtilities.dp;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.glassx.GlassConfig;
import org.telegram.messenger.glassx.GlassThemeEngine;
import org.telegram.ui.ActionBar.BaseFragment;
import org.telegram.ui.Components.LayoutHelper;
import org.telegram.ui.Components.glass.LiquidGlassKit;

/**
 * Appearance (theme, accent, bubbles, glass blur/opacity, rounding), AI assistant settings and ghost mode.
 * Every control applies instantly through GlassConfig.notifyChanged().
 */
public class GlassSettingsActivity extends BaseFragment {

    private LinearLayout content;
    private LiquidGlassKit.AuroraView aurora;
    private ScrollView scroll;

    @Override
    public View createView(Context context) {
        GlassConfig.load();
        setHasOwnBackground(true);
        actionBar.setAddToContainer(false);

        FrameLayout root = new FrameLayout(context);
        fragmentView = root;
        aurora = new LiquidGlassKit.AuroraView(context);
        root.addView(aurora, LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, LayoutHelper.MATCH_PARENT));

        scroll = new ScrollView(context);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, AndroidUtilities.statusBarHeight + dp(8), 0, dp(40));
        content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), 0, dp(14), 0);
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, LayoutHelper.createFrame(LayoutHelper.MATCH_PARENT, LayoutHelper.MATCH_PARENT));
        build();
        return root;
    }

    private void build() {
        content.removeAllViews();
        final Context ctx = content.getContext();
        final GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        aurora.refresh();

        TextView back = new TextView(ctx);
        back.setText("‹ Назад");
        back.setTextColor(p.accent);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        back.setPadding(dp(6), dp(8), dp(6), dp(8));
        back.setOnClickListener(v -> finishFragment());
        LiquidGlassKit.applyPressEffect(back);
        content.addView(back, wrap());

        TextView title = new TextView(ctx);
        title.setText("Внешний вид и ИИ");
        title.setTextColor(p.text);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(6), dp(4), 0, dp(10));
        content.addView(title, wrap());

        // ---- Themes
        LinearLayout themes = card(ctx, "ТЕМА");
        for (int i = 0; i < GlassConfig.THEME_COUNT; i++) {
            final int id = i;
            themes.addView(choiceRow(ctx, p, GlassThemeEngine.THEME_NAMES[i], GlassConfig.theme == i, () -> {
                GlassConfig.theme = id;
                GlassConfig.notifyChanged();
                build();
            }));
        }

        // ---- Accent
        LinearLayout accent = card(ctx, "АКЦЕНТНЫЙ ЦВЕТ");
        LinearLayout swatches = new LinearLayout(ctx);
        swatches.setOrientation(LinearLayout.HORIZONTAL);
        swatches.setPadding(dp(12), dp(6), dp(12), dp(12));
        swatches.addView(swatch(ctx, p, -1, 0));
        for (int i = 0; i < GlassConfig.ACCENTS.length; i++) {
            swatches.addView(swatch(ctx, p, i, GlassConfig.ACCENTS[i]));
        }
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(ctx);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(swatches);
        accent.addView(hs);

        // ---- Bubbles
        LinearLayout bubbles = card(ctx, "СТИЛЬ ПУЗЫРЕЙ");
        String[] bn = {"iOS (цветные)", "Стеклянные", "Плоские"};
        for (int i = 0; i < bn.length; i++) {
            final int id = i;
            bubbles.addView(choiceRow(ctx, p, bn[i], GlassConfig.bubbleStyle == i, () -> {
                GlassConfig.bubbleStyle = id;
                GlassConfig.notifyChanged();
                build();
            }));
        }

        // ---- Glass sliders
        LinearLayout glass = card(ctx, "СТЕКЛО");
        glass.addView(sliderRow(ctx, p, "Размытие", GlassConfig.glassBlur, 100, v -> {
            GlassConfig.glassBlur = v;
            GlassConfig.notifyChanged();
            aurora.refresh();
        }));
        glass.addView(sliderRow(ctx, p, "Непрозрачность стекла", GlassConfig.glassAlpha, 100, v -> {
            GlassConfig.glassAlpha = v;
            GlassConfig.notifyChanged();
        }));
        glass.addView(sliderRow(ctx, p, "Скругления (" + GlassConfig.cornerRadius + " dp)", GlassConfig.cornerRadius - 8, 22, v -> {
            GlassConfig.cornerRadius = v + 8;
            GlassConfig.notifyChanged();
        }));
        glass.addView(switchRow(ctx, p, "Живые переливы под стеклом", GlassConfig.liquidGlow, on -> {
            GlassConfig.liquidGlow = on;
            GlassConfig.notifyChanged();
            aurora.refresh();
        }));

        // ---- AI
        LinearLayout ai = card(ctx, "ИИ-АССИСТЕНТ (GEMINI)");
        ai.addView(labeledField(ctx, p, "API-ключ", GlassConfig.geminiKey, false, s -> {
            GlassConfig.geminiKey = s.trim();
            GlassConfig.save();
        }));
        ai.addView(labeledField(ctx, p, "Модель", GlassConfig.geminiModel, false, s -> {
            GlassConfig.geminiModel = s.trim();
            GlassConfig.save();
        }));
        ai.addView(labeledField(ctx, p, "Системная инструкция", GlassConfig.systemPrompt, true, s -> {
            GlassConfig.systemPrompt = s;
            GlassConfig.save();
        }));
        TextView reset = new TextView(ctx);
        reset.setText("Вернуть ключ по умолчанию");
        reset.setTextColor(p.accent);
        reset.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        reset.setPadding(dp(16), dp(10), dp(16), dp(14));
        reset.setOnClickListener(v -> {
            GlassConfig.resetGeminiKey();
            build();
        });
        LiquidGlassKit.applyPressEffect(reset);
        ai.addView(reset);

        // ---- Ghost mode
        LinearLayout ghost = card(ctx, "РЕЖИМ ПРИЗРАКА");
        ghost.addView(switchRow(ctx, p, "Не отправлять «прочитано»", GlassConfig.ghostNoRead, on -> {
            GlassConfig.ghostNoRead = on;
            GlassConfig.save();
        }));
        ghost.addView(switchRow(ctx, p, "Не показывать «печатает…»", GlassConfig.ghostNoTyping, on -> {
            GlassConfig.ghostNoTyping = on;
            GlassConfig.save();
        }));
        TextView note = new TextView(ctx);
        note.setText("Скрыть «в сети» можно в Настройки → Конфиденциальность → Был(а) в сети.");
        note.setTextColor(p.subtext);
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        note.setPadding(dp(16), 0, dp(16), dp(12));
        ghost.addView(note);
    }

    /* ---------- building blocks ---------- */

    private interface IntCb { void on(int v); }
    private interface BoolCb { void on(boolean v); }
    private interface StrCb { void on(String v); }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout card(Context ctx, String header) {
        GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        TextView h = new TextView(ctx);
        h.setText(header);
        h.setTextColor(p.subtext);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(dp(10), dp(18), 0, dp(6));
        content.addView(h, wrap());
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(LiquidGlassKit.glass(LiquidGlassKit.cornerDp(), false));
        content.addView(c, wrap());
        return c;
    }

    private View choiceRow(Context ctx, GlassThemeEngine.Palette p, String text, boolean selected, Runnable onClick) {
        LinearLayout row = new LinearLayout(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(13), dp(16), dp(13));
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextColor(p.text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (selected) {
            TextView check = new TextView(ctx);
            check.setText("✓");
            check.setTextColor(p.accent);
            check.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            check.setTypeface(Typeface.DEFAULT_BOLD);
            row.addView(check);
        }
        row.setOnClickListener(v -> onClick.run());
        LiquidGlassKit.applyPressEffect(row);
        return row;
    }

    private View swatch(Context ctx, GlassThemeEngine.Palette p, int index, int color) {
        TextView v = new TextView(ctx);
        v.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        if (index < 0) {
            d.setColors(new int[]{0xFF0A84FF, 0xFFBF5AF2, 0xFFFF375F});
            v.setText("A");
            v.setTextColor(Color.WHITE);
        } else {
            d.setColor(color);
        }
        if (GlassConfig.accentIndex == index) {
            d.setStroke(dp(3), p.text);
        } else {
            d.setStroke(dp(1), Color.argb(120, 255, 255, 255));
        }
        v.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(40));
        lp.rightMargin = dp(10);
        v.setLayoutParams(lp);
        v.setOnClickListener(x -> {
            GlassConfig.accentIndex = index;
            GlassConfig.notifyChanged();
            build();
        });
        LiquidGlassKit.applyPressEffect(v);
        return v;
    }

    private View sliderRow(Context ctx, GlassThemeEngine.Palette p, String label, int value, int max, IntCb cb) {
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(10), dp(16), dp(6));
        TextView t = new TextView(ctx);
        t.setText(label);
        t.setTextColor(p.text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        col.addView(t);
        SeekBar sb = new SeekBar(ctx);
        sb.setMax(max);
        sb.setProgress(value);
        sb.getProgressDrawable().setTint(p.accent);
        sb.getThumb().setTint(p.accent);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) { if (fromUser) cb.on(v); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        col.addView(sb);
        return col;
    }

    private View switchRow(Context ctx, GlassThemeEngine.Palette p, String label, boolean on, BoolCb cb) {
        LinearLayout row = new LinearLayout(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));
        TextView t = new TextView(ctx);
        t.setText(label);
        t.setTextColor(p.text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sw = new Switch(ctx);
        sw.setChecked(on);
        sw.getTrackDrawable().setTint(on ? p.accent : p.subtext);
        sw.setOnCheckedChangeListener((b, checked) -> {
            sw.getTrackDrawable().setTint(checked ? p.accent : p.subtext);
            cb.on(checked);
        });
        row.addView(sw);
        return row;
    }

    private View labeledField(Context ctx, GlassThemeEngine.Palette p, String label, String value, boolean multiline, StrCb cb) {
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(10), dp(16), dp(4));
        TextView t = new TextView(ctx);
        t.setText(label);
        t.setTextColor(p.subtext);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        col.addView(t);
        EditText e = new EditText(ctx);
        e.setText(value);
        e.setTextColor(p.text);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        e.setSingleLine(!multiline);
        e.setBackground(null);
        e.setPadding(0, dp(6), 0, dp(6));
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { cb.on(s.toString()); }
        });
        col.addView(e);
        return col;
    }

    @Override
    public boolean isLightStatusBar() {
        return !GlassThemeEngine.palette().dark;
    }
}
