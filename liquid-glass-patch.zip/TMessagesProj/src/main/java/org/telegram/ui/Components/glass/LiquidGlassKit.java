package org.telegram.ui.Components.glass;

import static org.telegram.messenger.AndroidUtilities.dp;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import androidx.core.graphics.ColorUtils;

import org.telegram.messenger.glassx.GlassConfig;
import org.telegram.messenger.glassx.GlassThemeEngine;

/** Helpers that give plain views the iOS Liquid Glass look: translucent fill, bright rim, soft depth, press response. */
public class LiquidGlassKit {

    /** Translucent glass surface with a light rim (specular edge) that follows the user's opacity/rounding settings. */
    public static LayerDrawable glass(float radiusDp, boolean strong) {
        GlassThemeEngine.Palette p = GlassThemeEngine.palette();
        int baseAlpha = (int) (255 * (0.35f + 0.6f * GlassConfig.glassAlpha / 100f));
        if (strong) {
            baseAlpha = Math.min(255, baseAlpha + 40);
        }
        int fill = ColorUtils.setAlphaComponent(p.dark ? 0xFF2C2C2E : 0xFFFFFFFF, baseAlpha);
        GradientDrawable body = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{ColorUtils.blendARGB(fill, Color.WHITE, p.dark ? 0.06f : 0.0f), fill});
        body.setCornerRadius(dp(radiusDp));
        GradientDrawable rim = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.argb(p.dark ? 120 : 220, 255, 255, 255), Color.argb(p.dark ? 20 : 60, 255, 255, 255), Color.argb(p.dark ? 70 : 140, 255, 255, 255)});
        rim.setCornerRadius(dp(radiusDp));
        rim.setStroke(Math.max(1, dp(1) / 1), Color.argb(p.dark ? 90 : 190, 255, 255, 255));
        rim.setColor(Color.TRANSPARENT);
        return new LayerDrawable(new android.graphics.drawable.Drawable[]{body, rim});
    }

    public static int cornerDp() {
        return GlassConfig.cornerRadius;
    }

    /** iOS-style press feedback: gentle scale down on touch, spring back on release. */
    public static void applyPressEffect(View v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.96f).scaleY(0.96f).alpha(0.85f).setDuration(110).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
                    break;
            }
            return false;
        });
    }

    /** Animated aurora: slow drifting colored glows. On Android 12+ it is additionally blurred so it reads as refracted light. */
    public static class AuroraView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ValueAnimator animator;
        private float t;

        public AuroraView(Context context) {
            super(context);
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(24000);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setInterpolator(new android.view.animation.LinearInterpolator());
            animator.addUpdateListener(a -> {
                t = (float) a.getAnimatedValue();
                invalidate();
            });
            applyBlur();
        }

        public void applyBlur() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                float r = dp(10 + 50 * GlassConfig.glassBlur / 100f);
                setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP));
            }
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (GlassConfig.liquidGlow) {
                animator.start();
            }
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            animator.cancel();
        }

        public void refresh() {
            applyBlur();
            if (GlassConfig.liquidGlow && !animator.isRunning() && isAttachedToWindow()) {
                animator.start();
            } else if (!GlassConfig.liquidGlow) {
                animator.cancel();
            }
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            GlassThemeEngine.Palette p = GlassThemeEngine.palette();
            final int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;
            canvas.drawColor(p.bg);
            if (!GlassConfig.liquidGlow) {
                return;
            }
            final double a = t * Math.PI * 2;
            final int alpha = p.dark ? 150 : 120;
            drawGlow(canvas, w * (0.2f + 0.15f * (float) Math.sin(a)), h * (0.18f + 0.1f * (float) Math.cos(a)), Math.max(w, h) * 0.55f, ColorUtils.setAlphaComponent(p.glowA, alpha));
            drawGlow(canvas, w * (0.85f + 0.1f * (float) Math.cos(a * 1.3)), h * (0.4f + 0.12f * (float) Math.sin(a * 1.3)), Math.max(w, h) * 0.5f, ColorUtils.setAlphaComponent(p.glowB, alpha));
            drawGlow(canvas, w * (0.45f + 0.2f * (float) Math.sin(a * 0.7)), h * (0.85f + 0.08f * (float) Math.cos(a * 0.7)), Math.max(w, h) * 0.6f, ColorUtils.setAlphaComponent(p.glowC, alpha));
        }

        private void drawGlow(Canvas c, float cx, float cy, float r, int color) {
            paint.setShader(new RadialGradient(cx, cy, r, color, ColorUtils.setAlphaComponent(color, 0), Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, paint);
        }
    }
}
